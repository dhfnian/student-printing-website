import React from "react"
export default function App(){
  return (<div style={{padding:20}}><h1>Student Printing</h1><p>Vite + React app scaffolded.</p></div>)
}
