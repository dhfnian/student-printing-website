# student-printing

Monorepo for student printing system.

- frontend: React + Vite
- backend: Node.js + Express
- store_pc: Python scripts for store PC integration
